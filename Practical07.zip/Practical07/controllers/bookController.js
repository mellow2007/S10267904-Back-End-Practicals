// controllers/bookController.js
const bookModel = require("../models/bookModel");

async function getAllBooks(req, res) {
    try {
        const books = await bookModel.getAllBooks();
        res.status(200).json(books);
    } catch (error) {
        console.error("Error getting books:", error);
        res.status(500).json({ message: "Internal server error" });
    }
}

async function updateAvailability(req, res) {
    const { bookId } = req.params;
    const { availability } = req.body;

    //  Role check: must be librarian
    if (req.user.role !== "librarian") {
        return res.status(403).json({ message: "Forbidden: Role not authorized" });
    }

    try {
        const result = await bookModel.updateBookAvailability(bookId, availability);
        res.status(200).json(result); // Should be { message: "...successfully" }
    } catch (error) {
        console.error("Error updating availability:", error);
        res.status(500).json({ message: "Internal server error" });
    }
}

module.exports = { getAllBooks, updateAvailability };
