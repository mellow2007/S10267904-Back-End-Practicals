// controllers/authController.js
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const sql = require("mssql");
const dbConfig = require("../dbConfig");

async function register(req, res) {
    const { username, password, role } = req.body;

    if (!username || !password || !role) {
        return res.status(400).json({ message: "All fields are required" });
    }

    let connection;
    try {
        connection = await sql.connect(dbConfig);

        // Check if user exists
        const result = await connection
            .request()
            .input("username", sql.VarChar, username)
            .query("SELECT * FROM Users WHERE username = @username");

        if (result.recordset.length > 0) {
            return res.status(400).json({ message: "Username already exists" });
        }

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        await connection
            .request()
            .input("username", sql.VarChar, username)
            .input("passwordHash", sql.VarChar, hashedPassword)
            .input("role", sql.VarChar, role)
            .query(
                "INSERT INTO Users (username, passwordHash, role) VALUES (@username, @passwordHash, @role)"
            );

        res.status(201).json({ message: "User registered successfully" });
    } catch (err) {
        console.error("Register error:", err);
        res.status(500).json({ message: "Internal server error" });
    } finally {
        if (connection) await connection.close();
    }
}

async function login(req, res) {
    const { username, password } = req.body;

    let connection;
    try {
        connection = await sql.connect(dbConfig);

        const result = await connection
            .request()
            .input("username", sql.VarChar, username)
            .query("SELECT * FROM Users WHERE username = @username");

        if (result.recordset.length === 0) {
            return res.status(401).json({ message: "Invalid credentials" });
        }

        const user = result.recordset[0];
        const isMatch = await bcrypt.compare(password, user.passwordHash);

        if (!isMatch) {
            return res.status(401).json({ message: "Invalid credentials" });
        }

        const token = jwt.sign(
            { id: user.user_id, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn: "1h" }
        );

        res.status(200).json({ token });
    } catch (err) {
        console.error("Login error:", err);
        res.status(500).json({ message: "Internal server error" });
    } finally {
        if (connection) await connection.close();
    }
}

module.exports = { register, login };
