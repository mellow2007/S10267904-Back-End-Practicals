// tests/books.test.js
const request = require("supertest");
const jwt = require("jsonwebtoken");
const app = require("../app");

// Ensure JWT_SECRET is set during the test
process.env.JWT_SECRET = process.env.JWT_SECRET || "testsecret";

// Mock the MSSQL package and database interaction
jest.mock("mssql", () => {
    return {
        connect: jest.fn().mockResolvedValue({
            request: () => ({
                query: jest.fn().mockImplementation((query) => {
                    if (query.includes("SELECT * FROM Books")) {
                        return Promise.resolve({
                            recordset: [
                                { book_id: 1, title: "Book One", availability: "Y" },
                                { book_id: 2, title: "Book Two", availability: "N" },
                            ],
                        });
                    }

                    if (query.includes("UPDATE Books")) {
                        return Promise.resolve(); // simulate success
                    }

                    return Promise.reject(new Error("Query not mocked"));
                }),
                input: function () {
                    return this;
                },
            }),
            close: jest.fn(),
        }),
    };
});

describe("Books API", () => {
    // Tokens with correct secret
    const librarianToken = jwt.sign({ id: 1, role: "librarian" }, process.env.JWT_SECRET);
    const memberToken = jwt.sign({ id: 2, role: "member" }, process.env.JWT_SECRET);

    describe("GET /books", () => {
        it("should return all books for authorized user", async () => {
            const res = await request(app)
                .get("/books")
                .set("Authorization", `Bearer ${librarianToken}`);

            expect(res.statusCode).toBe(200);
            expect(Array.isArray(res.body)).toBe(true);
            expect(res.body.length).toBeGreaterThan(0);
        });

        it("should return 401 if no token provided", async () => {
            const res = await request(app).get("/books");
            expect(res.statusCode).toBe(401);
            expect(res.body.message).toBe("Unauthorized: Token not provided");
        });
    });

    describe("PUT /books/:bookId/availability", () => {
        it("should update availability for librarian", async () => {
            const res = await request(app)
                .put("/books/1/availability")
                .send({ availability: "N" })
                .set("Authorization", `Bearer ${librarianToken}`);

            expect(res.statusCode).toBe(200);
            expect(res.body).toEqual({ message: "Availability updated successfully" });
        });

        it("should forbid update if role is member", async () => {
            const res = await request(app)
                .put("/books/1/availability")
                .send({ availability: "Y" })
                .set("Authorization", `Bearer ${memberToken}`);

            expect(res.statusCode).toBe(403);
            expect(res.body).toEqual({ message: "Forbidden: Role not authorized" });
        });
    });
});
