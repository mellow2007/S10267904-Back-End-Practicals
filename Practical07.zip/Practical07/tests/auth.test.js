// tests/auth.test.js
const request = require("supertest");
const app = require("../app");
const jwt = require("jsonwebtoken");

// Properly scoped MSSQL mock
jest.mock("mssql", () => {
    const mockRequest = {
        input: jest.fn().mockReturnThis(),
        query: jest.fn().mockImplementation((sql) => {
            if (sql.includes("SELECT * FROM Users WHERE username = 'newuser'")) {
                return { recordset: [] }; // Simulate no existing user
            }

            if (sql.includes("SELECT * FROM Users WHERE username = 'wronguser'")) {
                return { recordset: [] }; // Simulate failed login
            }

            if (sql.includes("INSERT INTO Users")) {
                return {}; // Simulate successful insert
            }

            return { recordset: [] };
        }),
    };

    return {
        connect: jest.fn().mockResolvedValue({
            request: jest.fn(() => mockRequest),
            close: jest.fn(),
        }),
        VarChar: jest.fn(),
        Int: jest.fn(),
        Char: jest.fn()
    };
});

describe("Auth Routes", () => {
    it("should register a new user", async () => {
        const res = await request(app).post("/register").send({
            username: "newuser",
            password: "securepass",
            role: "member",
        });

        expect(res.statusCode).toBe(201);
        expect(res.body.message).toBe("User registered successfully");
    });

    it("should fail login with invalid credentials", async () => {
        const res = await request(app).post("/login").send({
            username: "wronguser",
            password: "wrongpass",
        });

        expect(res.statusCode).toBe(401);
        expect(res.body.message).toBe("Invalid credentials");
    });
});
