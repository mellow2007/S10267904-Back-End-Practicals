// app.js
const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

const authController = require("./controllers/authController");
const bookController = require("./controllers/bookController");
const verifyJWT = require("./middleware/verifyJWT");

// Routes
app.post("/register", authController.register);
app.post("/login", authController.login);
app.get("/books", verifyJWT, bookController.getAllBooks);
app.put("/books/:bookId/availability", verifyJWT, bookController.updateAvailability);

module.exports = app;
