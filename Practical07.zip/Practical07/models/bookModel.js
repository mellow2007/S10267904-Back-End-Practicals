const sql = require("mssql");
const dbConfig = require("../dbConfig");

// Fetch all books
async function getAllBooks() {
    let connection;
    try {
        connection = await sql.connect(dbConfig);
        const result = await connection.request().query("SELECT * FROM Books");
        return result.recordset;
    } catch (error) {
        console.error("Error fetching books:", error);
        throw error;
    } finally {
        if (connection) await connection.close();
    }
}

// Update book availability
async function updateBookAvailability(bookId, availability) {
    let connection;
    try {
        connection = await sql.connect(dbConfig);
        await connection.request()
            .input("bookId", sql.Int, bookId)
            .input("availability", sql.Char(1), availability)
            .query("UPDATE Books SET availability = @availability WHERE book_id = @bookId");
        return { message: "Availability updated successfully" };
    } catch (error) {
        console.error("Error updating availability:", error);
        throw error;
    } finally {
        if (connection) await connection.close();
    }
}

module.exports = {
    getAllBooks,
    updateBookAvailability,
};
