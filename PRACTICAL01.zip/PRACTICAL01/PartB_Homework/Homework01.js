const express = require("express");
const app = express();
const PORT = 4000;

app.get("/", (req, res) => {
    res.send("Welcome to the Homework API");
});

app.get("/intro", (req, res) => {
    res.send("Not the Sharpest Tool in the Shed");
});

app.get("/name", (req, res) => {
    res.send("Amir Daiyan");
});

app.get("/hobbies", (req, res) => {
    res.send("Music, Watching Videos, Yugioh, Dragon Ball");
});

app.get("/food", (req, res) => {
    res.send("Favourite food: Breaded Beef, Sushi, Chicken Katsu<br>" +
        "Dislikes: Vegetables");
});




app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});