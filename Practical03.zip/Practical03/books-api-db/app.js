const express = require("express");
const sql = require("mssql");

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Database config
const dbConfig = {
    user: "booksapi_user",        // Change if needed
    password: "SUOCG7777",        // Change if needed
    server: "localhost",
    database: "bed_db",           // Using existing bed_db
    trustServerCertificate: true,
    options: {
        port: 1433,
        connectionTimeout: 30000,
    },
};

// GET all students
app.get("/students", async (req, res) => {
    let connection;
    try {
        connection = await sql.connect(dbConfig);
        const result = await connection.request().query("SELECT * FROM Students");
        res.json(result.recordset);
    } catch (error) {
        console.error("Error fetching students:", error);
        res.status(500).json({ error: "Internal server error" });
    } finally {
        if (connection) await connection.close();
    }
});

// GET student by ID
app.get("/students/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    let connection;
    try {
        connection = await sql.connect(dbConfig);
        const request = connection.request();
        request.input("id", id);
        const result = await request.query("SELECT * FROM Students WHERE student_id = @id");

        if (result.recordset.length === 0) {
            return res.status(404).json({ error: "Student not found" });
        }

        res.json(result.recordset[0]);
    } catch (error) {
        console.error("Error fetching student:", error);
        res.status(500).json({ error: "Internal server error" });
    } finally {
        if (connection) await connection.close();
    }
});

// POST new student
app.post("/students", async (req, res) => {
    const { name, address } = req.body;
    if (!name) {
        return res.status(400).json({ error: "Name is required" });
    }

    let connection;
    try {
        connection = await sql.connect(dbConfig);
        const request = connection.request();
        request.input("name", name);
        request.input("address", address || null);
        const result = await request.query(
            `INSERT INTO Students (name, address)
       VALUES (@name, @address);
       SELECT SCOPE_IDENTITY() AS id;`
        );

        const newId = result.recordset[0].id;
        const newStudent = await connection
            .request()
            .input("id", newId)
            .query("SELECT * FROM Students WHERE student_id = @id");

        res.status(201).json(newStudent.recordset[0]);
    } catch (error) {
        console.error("Error creating student:", error);
        res.status(500).json({ error: "Internal server error" });
    } finally {
        if (connection) await connection.close();
    }
});

// PUT update student
app.put("/students/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const { name, address } = req.body;

    let connection;
    try {
        connection = await sql.connect(dbConfig);
        const request = connection.request();
        request.input("id", id);
        request.input("name", name || null);
        request.input("address", address || null);

        const result = await request.query(
            `UPDATE Students
       SET name = @name, address = @address
       WHERE student_id = @id`
        );

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: "Student not found" });
        }

        const updatedStudent = await connection
            .request()
            .input("id", id)
            .query("SELECT * FROM Students WHERE student_id = @id");

        res.json(updatedStudent.recordset[0]);
    } catch (error) {
        console.error("Error updating student:", error);
        res.status(500).json({ error: "Internal server error" });
    } finally {
        if (connection) await connection.close();
    }
});

// DELETE student
app.delete("/students/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    let connection;
    try {
        connection = await sql.connect(dbConfig);
        const request = connection.request();
        request.input("id", id);
        const result = await request.query("DELETE FROM Students WHERE student_id = @id");

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: "Student not found" });
        }

        res.status(204).send(); // No content
    } catch (error) {
        console.error("Error deleting student:", error);
        res.status(500).json({ error: "Internal server error" });
    } finally {
        if (connection) await connection.close();
    }
});

// Start server
app.listen(port, () => {
    console.log(`Students API running on port ${port}`);
});

// Graceful shutdown
process.on("SIGINT", async () => {
    console.log("Server shutting down...");
    await sql.close();
    process.exit(0);
});
