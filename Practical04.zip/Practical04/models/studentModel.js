const sql = require("mssql");
const dbConfig = require("../dbConfig");

async function getAllStudents() {
    const connection = await sql.connect(dbConfig);
    const result = await connection.request().query("SELECT * FROM Students");
    return result.recordset;
}

async function getStudentById(id) {
    const connection = await sql.connect(dbConfig);
    const request = connection.request().input("id", id);
    const result = await request.query("SELECT * FROM Students WHERE student_id = @id");
    return result.recordset[0] || null;
}

async function createStudent(data) {
    const connection = await sql.connect(dbConfig);
    const request = connection.request();
    request.input("name", data.name);
    request.input("address", data.address || null);

    const insertResult = await request.query(
        `INSERT INTO Students (name, address)
     VALUES (@name, @address);
     SELECT SCOPE_IDENTITY() AS id;`
    );

    const newId = insertResult.recordset[0].id;
    return await getStudentById(newId);
}

async function updateStudent(id, data) {
    const connection = await sql.connect(dbConfig);
    const request = connection.request();
    request.input("id", id);
    request.input("name", data.name);
    request.input("address", data.address || null);

    const result = await request.query(
        `UPDATE Students
     SET name = @name, address = @address
     WHERE student_id = @id`
    );

    if (result.rowsAffected[0] === 0) return null;
    return await getStudentById(id);
}

async function deleteStudent(id) {
    const connection = await sql.connect(dbConfig);
    const result = await connection
        .request()
        .input("id", id)
        .query("DELETE FROM Students WHERE student_id = @id");

    return result.rowsAffected[0] > 0;
}

module.exports = {
    getAllStudents,
    getStudentById,
    createStudent,
    updateStudent,
    deleteStudent,
};
