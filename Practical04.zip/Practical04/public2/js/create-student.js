const apiBaseUrl = "http://localhost:3000";
const form = document.getElementById("createStudentForm");
const messageDiv = document.getElementById("message");

form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = document.getElementById("name").value.trim();
    const address = document.getElementById("address").value.trim();

    if (!name) {
        messageDiv.textContent = "Name is required.";
        messageDiv.style.color = "red";
        return;
    }

    try {
        const res = await fetch(`${apiBaseUrl}/students`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, address }),
        });

        if (res.ok) {
            messageDiv.textContent = "Student created!";
            messageDiv.style.color = "green";
            form.reset();
            setTimeout(() => window.location.href = "students.html", 1500);
        } else {
            const err = await res.json();
            messageDiv.textContent = err.error || "Creation failed.";
            messageDiv.style.color = "red";
        }
    } catch (err) {
        messageDiv.textContent = "Error creating student.";
        messageDiv.style.color = "red";
    }
});
