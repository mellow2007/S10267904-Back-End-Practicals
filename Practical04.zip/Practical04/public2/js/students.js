const apiBaseUrl = "http://localhost:3000";
const tableBody = document.getElementById("studentsTableBody");
const messageDiv = document.getElementById("message");

async function fetchStudents() {
    try {
        const res = await fetch(`${apiBaseUrl}/students`);
        const students = await res.json();
        tableBody.innerHTML = "";
        students.forEach((student) => {
            const row = document.createElement("tr");
            row.innerHTML = `
        <td>${student.student_id}</td>
        <td>${student.name}</td>
        <td>${student.address || ""}</td>
        <td>
          <a href="edit-student.html?id=${student.student_id}">
            <button class="edit">Edit</button>
          </a>
          <button class="delete" onclick="deleteStudent(${student.student_id})">Delete</button>
        </td>
      `;
            tableBody.appendChild(row);
        });
    } catch (err) {
        messageDiv.textContent = "Error loading students.";
        messageDiv.style.color = "red";
    }
}

async function deleteStudent(id) {
    if (!confirm("Are you sure you want to delete this student?")) return;
    try {
        const res = await fetch(`${apiBaseUrl}/students/${id}`, { method: "DELETE" });
        if (res.status === 204) {
            fetchStudents();
        } else {
            const data = await res.json();
            messageDiv.textContent = data.error || "Failed to delete student.";
            messageDiv.style.color = "red";
        }
    } catch (err) {
        messageDiv.textContent = "Delete failed.";
        messageDiv.style.color = "red";
    }
}

fetchStudents();
