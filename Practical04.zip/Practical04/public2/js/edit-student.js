const apiBaseUrl = "http://localhost:3000";
const form = document.getElementById("editStudentForm");
const loadingMessageDiv = document.getElementById("loadingMessage");
const messageDiv = document.getElementById("message");

const studentIdInput = document.getElementById("studentId");
const editNameInput = document.getElementById("editName");
const editAddressInput = document.getElementById("editAddress");

function getIdFromUrl() {
    const params = new URLSearchParams(window.location.search);
    return params.get("id");
}

async function fetchStudent(id) {
    try {
        const res = await fetch(`${apiBaseUrl}/students/${id}`);
        if (!res.ok) throw new Error("Student not found.");
        const student = await res.json();
        studentIdInput.value = student.student_id;
        editNameInput.value = student.name;
        editAddressInput.value = student.address || "";
        form.style.display = "block";
        loadingMessageDiv.style.display = "none";
    } catch (err) {
        loadingMessageDiv.textContent = "Failed to load student.";
        messageDiv.textContent = err.message;
        messageDiv.style.color = "red";
    }
}

form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = studentIdInput.value;
    const name = editNameInput.value.trim();
    const address = editAddressInput.value.trim();

    if (!name) {
        messageDiv.textContent = "Name is required.";
        messageDiv.style.color = "red";
        return;
    }

    try {
        const res = await fetch(`${apiBaseUrl}/students/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, address }),
        });

        if (res.ok) {
            messageDiv.textContent = "Student updated!";
            messageDiv.style.color = "green";
            setTimeout(() => window.location.href = "students.html", 1500);
        } else {
            const err = await res.json();
            messageDiv.textContent = err.error || "Update failed.";
            messageDiv.style.color = "red";
        }
    } catch (err) {
        messageDiv.textContent = "Error updating student.";
        messageDiv.style.color = "red";
    }
});

fetchStudent(getIdFromUrl());
