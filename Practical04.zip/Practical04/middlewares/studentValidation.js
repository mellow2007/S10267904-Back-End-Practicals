const Joi = require("joi");

const studentSchema = Joi.object({
    name: Joi.string().min(1).max(100).required().messages({
        "any.required": "Name is required",
        "string.empty": "Name cannot be empty",
    }),
    address: Joi.string().max(255).allow("", null),
});

function validateStudent(req, res, next) {
    const { error } = studentSchema.validate(req.body, { abortEarly: false });
    if (error) {
        const messages = error.details.map((d) => d.message).join(", ");
        return res.status(400).json({ error: messages });
    }
    next();
}

function validateId(req, res, next) {
    const id = parseInt(req.params.id);
    if (isNaN(id) || id <= 0) {
        return res.status(400).json({ error: "Invalid student ID" });
    }
    next();
}

module.exports = { validateStudent, validateId };
