const model = require("../models/studentModel");

async function getAll(req, res) {
    try {
        const students = await model.getAllStudents();
        res.json(students);
    } catch (err) {
        console.error("Get All Error:", err);
        res.status(500).json({ error: "Internal server error" });
    }
}

async function getById(req, res) {
    try {
        const id = parseInt(req.params.id);
        const student = await model.getStudentById(id);
        if (!student) return res.status(404).json({ error: "Student not found" });
        res.json(student);
    } catch (err) {
        res.status(500).json({ error: "Internal server error" });
    }
}

async function create(req, res) {
    try {
        const student = await model.createStudent(req.body);
        res.status(201).json(student);
    } catch (err) {
        res.status(500).json({ error: "Internal server error" });
    }
}

async function update(req, res) {
    try {
        const id = parseInt(req.params.id);
        const student = await model.updateStudent(id, req.body);
        if (!student) return res.status(404).json({ error: "Student not found" });
        res.json(student);
    } catch (err) {
        res.status(500).json({ error: "Internal server error" });
    }
}

async function remove(req, res) {
    try {
        const id = parseInt(req.params.id);
        const deleted = await model.deleteStudent(id);
        if (!deleted) return res.status(404).json({ error: "Student not found" });
        res.status(204).send();
    } catch (err) {
        res.status(500).json({ error: "Internal server error" });
    }
}

module.exports = { getAll, getById, create, update, remove };
