const express = require("express");
const sql = require("mssql");
const dotenv = require("dotenv");
const path = require("path"); // ensure this is at the top



dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

const controller = require("./controllers/studentController");
const { validateStudent, validateId } = require("./middlewares/studentValidation");
// Serve static files from 'public2'
app.use(express.static(path.join(__dirname, "public2")));
// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.get("/students", controller.getAll);
app.get("/students/:id", validateId, controller.getById);
app.post("/students", validateStudent, controller.create);
app.put("/students/:id", validateId, validateStudent, controller.update);
app.delete("/students/:id", validateId, controller.remove);

// Start server
app.listen(port, () => {
    console.log(`Students API running on port ${port}`);
});

// Graceful shutdown
process.on("SIGINT", async () => {
    console.log("Shutting down server...");
    await sql.close();
    process.exit(0);
});
