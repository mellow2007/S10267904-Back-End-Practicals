// Get references to the elements
const editBookForm = document.getElementById("editBookForm");
const loadingMessageDiv = document.getElementById("loadingMessage");
const messageDiv = document.getElementById("message");
const bookIdInput = document.getElementById("bookId");
const editTitleInput = document.getElementById("editTitle");
const editAuthorInput = document.getElementById("editAuthor");

// Base URL for the API.
const apiBaseUrl = "http://localhost:3000";

// Get book ID from URL
function getBookIdFromUrl() {
    const params = new URLSearchParams(window.location.search);
    return params.get("id");
}

// Fetch book data by ID
async function fetchBookData(bookId) {
    try {
        const response = await fetch(`${apiBaseUrl}/books/${bookId}`);
        if (!response.ok) {
            const errorBody = response.headers.get("content-type")?.includes("application/json")
                ? await response.json()
                : { message: response.statusText };
            throw new Error(`HTTP error! status: ${response.status}, message: ${errorBody.message}`);
        }
        const book = await response.json();
        return book;
    } catch (error) {
        console.error("Error fetching book data:", error);
        messageDiv.textContent = `Failed to load book data: ${error.message}`;
        messageDiv.style.color = "red";
        loadingMessageDiv.textContent = "";
        return null;
    }
}

// Populate form with book data
function populateForm(book) {
    bookIdInput.value = book.id;
    editTitleInput.value = book.title;
    editAuthorInput.value = book.author;
    loadingMessageDiv.style.display = "none";
    editBookForm.style.display = "block";
}

// --- Page load logic ---
const bookIdToEdit = getBookIdFromUrl();
if (bookIdToEdit) {
    fetchBookData(bookIdToEdit).then((book) => {
        if (book) {
            populateForm(book);
        } else {
            loadingMessageDiv.textContent = "Book not found or failed to load.";
            messageDiv.textContent = "Could not find the book to edit.";
            messageDiv.style.color = "red";
        }
    });
} else {
    loadingMessageDiv.textContent = "No book ID specified for editing.";
    messageDiv.textContent = "Please provide a book ID in the URL (e.g., edit.html?id=1).";
    messageDiv.style.color = "orange";
}

// --- PUT Request logic on form submission ---
editBookForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const updatedTitle = editTitleInput.value.trim();
    const updatedAuthor = editAuthorInput.value.trim();
    const bookId = bookIdInput.value;

    if (!updatedTitle || !updatedAuthor) {
        messageDiv.textContent = "Both title and author are required.";
        messageDiv.style.color = "red";
        return;
    }

    try {
        const response = await fetch(`${apiBaseUrl}/books/${bookId}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ title: updatedTitle, author: updatedAuthor }),
        });

        if (response.ok) {
            messageDiv.textContent = "Book updated successfully!";
            messageDiv.style.color = "green";
            setTimeout(() => {
                window.location.href = "index.html";
            }, 1500);
        } else {
            const errorBody = response.headers.get("content-type")?.includes("application/json")
                ? await response.json()
                : { error: response.statusText };

            if (response.status === 400) {
                messageDiv.textContent = `Validation error: ${errorBody.error}`;
            } else if (response.status === 404) {
                messageDiv.textContent = "Book not found.";
            } else {
                messageDiv.textContent = `Server error: ${errorBody.error || "Unknown error"}`;
            }
            messageDiv.style.color = "red";
        }
    } catch (error) {
        console.error("Error updating book:", error);
        messageDiv.textContent = `Error updating book: ${error.message}`;
        messageDiv.style.color = "red";
    }
});
