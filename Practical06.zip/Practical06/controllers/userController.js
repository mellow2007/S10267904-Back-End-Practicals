// controllers/userController.js
const User = require("../models/userModel");

// Create a new user
async function createUser(req, res) {
    const { username, email } = req.body;

    try {
        const newUser = await User.createUser({ username, email });
        res.status(201).json({ message: "User created successfully", user: newUser });
    } catch (error) {
        console.error("Error creating user:", error);
        res.status(500).json({ error: "Failed to create user" });
    }
}

// Get all users
async function getAllUsers(req, res) {
    try {
        const users = await User.getAllUsers();
        res.status(200).json(users);
    } catch (error) {
        console.error("Error fetching users:", error);
        res.status(500).json({ error: "Failed to retrieve users" });
    }
}

// Get a user by ID
async function getUserById(req, res) {
    const { id } = req.params;

    try {
        const user = await User.getUserById(id);
        if (!user) {
            return res.status(404).json({ error: "User not found" });
        }
        res.status(200).json(user);
    } catch (error) {
        console.error("Error fetching user:", error);
        res.status(500).json({ error: "Failed to retrieve user" });
    }
}

// Update user
async function updateUser(req, res) {
    const { id } = req.params;
    const { username, email } = req.body;

    try {
        const success = await User.updateUser(id, { username, email });
        if (!success) {
            return res.status(404).json({ error: "User not found or not updated" });
        }
        res.status(200).json({ message: "User updated successfully" });
    } catch (error) {
        console.error("Error updating user:", error);
        res.status(500).json({ error: "Failed to update user" });
    }
}

// Delete user
async function deleteUser(req, res) {
    const { id } = req.params;

    try {
        const success = await User.deleteUser(id);
        if (!success) {
            return res.status(404).json({ error: "User not found or already deleted" });
        }
        res.status(200).json({ message: "User deleted successfully" });
    } catch (error) {
        console.error("Error deleting user:", error);
        res.status(500).json({ error: "Failed to delete user" });
    }
}
// Get users with their books
async function getUsersWithBooks(req, res) {
    try {
        const users = await User.getUsersWithBooks();
        res.json(users);
    } catch (error) {
        console.error("Controller error in getUsersWithBooks:", error);
        res.status(500).json({ message: "Error fetching users with books" });
    }
}


module.exports = {
    createUser,
    getAllUsers,
    getUserById,
    updateUser,
    deleteUser,
    getUsersWithBooks

};
