const sql = require("mssql");
const dbConfig = require("../dbConfig");

async function createUser(user) {
    let connection;
    try {
        connection = await sql.connect(dbConfig);
        const result = await connection
            .request()
            .input("username", sql.VarChar, user.username)
            .input("email", sql.VarChar, user.email)
            .query(
                "INSERT INTO Users (username, email) VALUES (@username, @email); SELECT * FROM Users WHERE id = SCOPE_IDENTITY();"
            );

        return result.recordset[0];
    } catch (error) {
        console.error("Error creating user:", error);
        throw error;
    } finally {
        if (connection) await connection.close();
    }
}

async function getAllUsers() {
    let connection;
    try {
        connection = await sql.connect(dbConfig);
        const result = await connection.request().query("SELECT * FROM Users");
        return result.recordset;
    } catch (error) {
        console.error("Error fetching users:", error);
        throw error;
    } finally {
        if (connection) await connection.close();
    }
}

async function getUserById(id) {
    let connection;
    try {
        connection = await sql.connect(dbConfig);
        const result = await connection
            .request()
            .input("id", sql.Int, id)
            .query("SELECT * FROM Users WHERE id = @id");

        return result.recordset[0];
    } catch (error) {
        console.error("Error fetching user by ID:", error);
        throw error;
    } finally {
        if (connection) await connection.close();
    }
}

async function updateUser(id, updatedUser) {
    let connection;
    try {
        connection = await sql.connect(dbConfig);
        await connection
            .request()
            .input("id", sql.Int, id)
            .input("username", sql.VarChar, updatedUser.username)
            .input("email", sql.VarChar, updatedUser.email)
            .query(
                "UPDATE Users SET username = @username, email = @email WHERE id = @id"
            );

        return { message: "User updated successfully" };
    } catch (error) {
        console.error("Error updating user:", error);
        throw error;
    } finally {
        if (connection) await connection.close();
    }
}

async function deleteUser(id) {
    let connection;
    try {
        connection = await sql.connect(dbConfig);
        await connection
            .request()
            .input("id", sql.Int, id)
            .query("DELETE FROM Users WHERE id = @id");

        return { message: "User deleted successfully" };
    } catch (error) {
        console.error("Error deleting user:", error);
        throw error;
    } finally {
        if (connection) await connection.close();
    }
}

async function getUsersWithBooks() {
    let connection;
    try {
        connection = await sql.connect(dbConfig);
        const query = `
      SELECT u.id AS user_id, u.username, u.email, b.id AS book_id, b.title, b.author
      FROM Users u
      LEFT JOIN UserBooks ub ON ub.user_id = u.id
      LEFT JOIN Books b ON ub.book_id = b.id
      ORDER BY u.username;
    `;
        const result = await connection.request().query(query);

        const usersWithBooks = {};
        for (const row of result.recordset) {
            const userId = row.user_id;
            if (!usersWithBooks[userId]) {
                usersWithBooks[userId] = {
                    id: userId,
                    username: row.username,
                    email: row.email,
                    books: [],
                };
            }
            if (row.book_id !== null) {
                usersWithBooks[userId].books.push({
                    id: row.book_id,
                    title: row.title,
                    author: row.author,
                });
            }
        }

        return Object.values(usersWithBooks);
    } catch (error) {
        console.error("Database error in getUsersWithBooks:", error);
        throw error;
    } finally {
        if (connection) await connection.close();
    }
}

module.exports = {
    createUser,
    getAllUsers,
    getUserById,
    updateUser,
    deleteUser,
    getUsersWithBooks
};
